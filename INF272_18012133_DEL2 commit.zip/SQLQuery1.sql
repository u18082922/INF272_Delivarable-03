USE master;
ALTER DATABASE QUESTIONANDANSWER SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DROP DATABASE QUESTIONANDANSWER;
create database QUESTIONANDANSWER
go
use QUESTIONANDANSWER
go
CREATE TABLE QUESTIONANDANSWER
(
	ID INT PRIMARY KEY IDENTITY(1,1),
	QUESTION INT,
	ANSWER INT
)

CREATE TABLE QUESTIONS
(
	QUESTION_ID INT PRIMARY KEY IDENTITY(1,1),
	QUESTION VARCHAR (50),
	ANSWER1 VARCHAR (50),
	ANSWER2 VARCHAR (50),
	ANSWER3 VARCHAR (50),
	ANSWER4 VARCHAR (50),
	TRUEANSWER VARCHAR (50),
	CATEGORY INT
)

INSERT INTO QUESTIONS values('which animal is a mamal?','cat','Fish','Bear','Dog','Fish',1)
INSERT INTO QUESTIONS values('This is numeracy2','answer 1','answer 2','answer 3','answer 4','answer 2',1)
INSERT INTO QUESTIONS values('This is numeracy3','answer 1','answer 2','answer 3','answer 4','answer 4',1)
INSERT INTO QUESTIONS values('This is numeracy4','answer 1','answer 2','answer 3','answer 4','answer 1',1)
INSERT INTO QUESTIONS values('This is numeracy5','answer 1','answer 2','answer 3','answer 4','answer 3',1)
INSERT INTO QUESTIONS values('This is numeracy6','answer 1','answer 2','answer 3','answer 4','answer 2',1)
INSERT INTO QUESTIONS values('This is numeracy7','answer 1','answer 2','answer 3','answer 4','answer 4',1)
INSERT INTO QUESTIONS values('This is numeracy8','answer 1','answer 2','answer 3','answer 4','answer 3',1)




INSERT INTO QUESTIONS values('This is num1','answer 1','answer 2','answer 3','answer 4','answer 3',2)
INSERT INTO QUESTIONS values('This is num2','answer 1','answer 2','answer 3','answer 4','answer 2',2)
INSERT INTO QUESTIONS values('This is num3','answer 1','answer 2','answer 3','answer 4','answer 4',2)
INSERT INTO QUESTIONS values('This is num4','answer 1','answer 2','answer 3','answer 4','answer 1',2)
INSERT INTO QUESTIONS values('This is num5','answer 1','answer 2','answer 3','answer 4','answer 3',2)
INSERT INTO QUESTIONS values('This is num6','answer 1','answer 2','answer 3','answer 4','answer 2',2)
INSERT INTO QUESTIONS values('This is num7','answer 1','answer 2','answer 3','answer 4','answer 4',2)
INSERT INTO QUESTIONS values('This is num8','answer 1','answer 2','answer 3','answer 4','answer 3',2)



INSERT INTO QUESTIONS values('This is another numeracy1','answer 1','answer 2','answer 3','answer 4','answer 3',3)
INSERT INTO QUESTIONS values('This is another numeracy2','answer 1','answer 2','answer 3','answer 4','answer 2',3)
INSERT INTO QUESTIONS values('This is another numeracy3','answer 1','answer 2','answer 3','answer 4','answer 4',3)
INSERT INTO QUESTIONS values('This is another numeracy4','answer 1','answer 2','answer 3','answer 4','answer 1',3)
INSERT INTO QUESTIONS values('This is another numeracy5','answer 1','answer 2','answer 3','answer 4','answer 3',3)
INSERT INTO QUESTIONS values('This is another numeracy6','answer 1','answer 2','answer 3','answer 4','answer 2',3)
INSERT INTO QUESTIONS values('This is another numeracy7','answer 1','answer 2','answer 3','answer 4','answer 4',3)
INSERT INTO QUESTIONS values('This is another numeracy8','answer 1','answer 2','answer 3','answer 4','answer 3',3)



INSERT INTO QUESTIONS values('This is another num1','answer 1','answer 2','answer 3','answer 4','answer 3',4)
INSERT INTO QUESTIONS values('This is another num2','answer 1','answer 2','answer 3','answer 4','answer 2',4)
INSERT INTO QUESTIONS values('This is another num3','answer 1','answer 2','answer 3','answer 4','answer 4',4)
INSERT INTO QUESTIONS values('This is another num4','answer 1','answer 2','answer 3','answer 4','answer 1',4)
INSERT INTO QUESTIONS values('This is another num5','answer 1','answer 2','answer 3','answer 4','answer 3',4)
INSERT INTO QUESTIONS values('This is another num6','answer 1','answer 2','answer 3','answer 4','answer 2',4)
INSERT INTO QUESTIONS values('This is another num7','answer 1','answer 2','answer 3','answer 4','answer 4',4)
INSERT INTO QUESTIONS values('This is another num8','answer 1','answer 2','answer 3','answer 4','answer 3',4)
